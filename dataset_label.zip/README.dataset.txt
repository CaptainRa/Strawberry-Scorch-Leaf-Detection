# Tugas Besar Visi Komputer > version1
https://universe.roboflow.com/coba1-llfmc/tugas-besar-visi-komputer

Provided by a Roboflow user
License: CC BY 4.0

